# shikayaat
This project is used to raise complaints and queries.


shikayaat is a digital complaint box that allows you to file complaints online and get instant feedback from the organisation. It is a web-based application that is designed to be used by people in the organisation to easify the long and hectic complain raising and resolving process by providing a suitable online platform for the complain filing and resolving.

 - Developer

